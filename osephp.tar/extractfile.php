<?php
try {
    $phar = new Phar('/Users/apple/Desktop/osephp.phar');
    $phar->extractTo('/Users/apple/Desktop/PharFiles'); // extract all files
    
    
} catch (Exception $e) {
    // handle errors
}
?>